`print.boot632` <-
function (x, ...) 
{
    cat("\nNONPARAMETRIC BOOTSTRAP-0.632\n\n")
    cat("Call:\n")
    print(x$call)
    cat("\nBootstrap-0.632 Statistics:\n\n")
    w <- data.frame(app.err = x$app.err, optim = x$optim, err.632 = x$err.632)
    row.names(w) <- "value"
    print(w)
    cat("\n")
}
