modperf.lm <-
function (x, ...) 
{
    .NotYetImplemented()
}
