.First.lib <- function(lib, pkg) {
  library.dynam("modtools", pkg, lib)
}




  

