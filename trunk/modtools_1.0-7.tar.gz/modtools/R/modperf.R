modperf <-
function (x, ...) 
{
    UseMethod("modperf")
}
