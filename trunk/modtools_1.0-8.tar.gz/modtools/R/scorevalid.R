`scorevalid` <-
function (y, score, ...) 
{
    UseMethod("scorevalid")
}
