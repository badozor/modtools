`sefit` <-
function (object, ...) 
{
    UseMethod("sefit")
}
