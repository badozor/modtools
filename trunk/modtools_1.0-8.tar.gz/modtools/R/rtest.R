mean.rtest <- function(x,y,nrepet = 99){
	xy <- c(x,y)
	group <- c(rep("x",length(x)),rep("y",length(y)))
	obs <- abs(mean(xy[group=="x"])-mean(xy[group=="y"]))
	if (nrepet == 0) 
		return(obs)
	perm <- matrix(0, nrow = nrepet, ncol = 1)
	perm <- apply(perm, 1, function(z){rndgroup <- sample(group); abs(mean(xy[rndgroup=="x"])-mean(xy[rndgroup=="y"]))})
	w <- as.rtest(obs = obs, sim = perm, call = match.call())
	return(w)
}
t.rtest <- function(x,y,nrepet = 99,...){
	xy <- c(x,y)
	group <- c(rep("x",length(x)),rep("y",length(y)))
	obs <- abs(t.test(xy[group=="x"],xy[group=="y"],...)$statistic)
	if (nrepet == 0) 
		return(obs)
	perm <- matrix(0, nrow = nrepet, ncol = 1)
	perm <- apply(perm, 1, function(z){rndgroup <- sample(group); abs(t.test(xy[rndgroup=="x"],xy[rndgroup=="y"],...)$statistic)})
	w <- as.rtest(obs = obs, sim = perm, call = match.call())
	return(w)
}
median.rtest <- function(x,y,nrepet = 99){
	xy <- c(x,y)
	group <- c(rep("x",length(x)),rep("y",length(y)))
	obs <- abs(median(xy[group=="x"])-median(xy[group=="y"]))
	if (nrepet == 0) 
		return(obs)
	perm <- matrix(0, nrow = nrepet, ncol = 1)
	perm <- apply(perm, 1, function(z){rndgroup <- sample(group); abs(median(xy[rndgroup=="x"])-median(xy[rndgroup=="y"]))})
	w <- as.rtest(obs = obs, sim = perm, call = match.call())
	return(w)
	
}
