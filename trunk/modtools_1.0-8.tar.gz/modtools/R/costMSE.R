`costMSE` <-
function (y, yhat = 0) 
mean((y - yhat)^2)
