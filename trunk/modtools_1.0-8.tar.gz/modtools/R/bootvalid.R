`bootvalid` <-
function (object, ...) 
{
    UseMethod("bootvalid")
}
