### Name: cost
### Title: Cost functions
### Aliases: cost costAVER costBIN costMAE costMSE costRMSE costKappa
###   costGoodCl costSlope costOri costR2


### ** Examples

x <- rnorm(20,2,5)
y <- -6+x*3+rnorm(20)
lm1 <- lm(y~x)
costRMSE(y,lm1$fitted)



