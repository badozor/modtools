### Name: roc
### Title: ROC functions
### Aliases: roc prep.roc plot.roc print.roc summary.roc ROCcoordinate
###   optimCut fgoodclassif fkappa fSpecSens fSpecSens2


### ** Examples

x <- rnorm( 100 )
z <- rnorm( 100 )
w <- rnorm( 100 )
tigol <- function( x ) 1 - ( 1 + exp( x ) )^(-1)
y <- rbinom( 100, 1, tigol( 0.3 + 3*x + 5*z + 7*w ) )
ROC( form = y ~ x + z, plot="ROC" )
glm1 <- glm(y ~ x + z,family=binomial)
roc1 <- prep.roc(glm1$y,glm1$fitted)
plot(roc1)



