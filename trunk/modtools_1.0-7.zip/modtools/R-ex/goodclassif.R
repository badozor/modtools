### Name: goodclassif
### Title: Good classification
### Aliases: goodclassif


### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function (x) 
{
    if (ncol(x) != nrow(x)) 
        stop("non covenient dimension !")
    N <- sum(x)
    sxii <- sum(diag(x))
    return(sxii/N)
  }



