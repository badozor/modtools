### Name: modtools-package
### Title: Additional tools for model diagnostic and selection
### Aliases: modtools-package modtools


### ** Examples

# nothing for the moment



