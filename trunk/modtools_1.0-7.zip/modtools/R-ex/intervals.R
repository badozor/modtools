### Name: intervals
### Title: confidence and prediction/tolerance intervals for glm
### Aliases: intervals intervals.glm intervals.robclust


### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function (object, ...) 
{
    UseMethod("intervals")
  }



