### Name: modplot
### Title: Plot Diagnostics for glm and lm Objects
### Aliases: plotBoot plotCovPat plotEtaRes plotHalfnorm plotLeverage
###   plotObsExp plotObsExpCat plotParRes plotQQres plotResDens
###   envelope.bin


### ** Examples

### plot



