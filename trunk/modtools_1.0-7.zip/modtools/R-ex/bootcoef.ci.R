### Name: bootcoef.ci
### Title: ~~function to do ... ~~
### Aliases: bootcoef.ci


### ** Examples


# add an example




