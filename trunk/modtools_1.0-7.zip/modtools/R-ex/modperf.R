### Name: modperf
### Title: Model performance
### Aliases: modperf modperf.cv modperf.boot modperf.lm modperf.glm
###   modperf.binary modperf.default perfbinary


### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function (x, ...) 
{
    UseMethod("modperf")
  }



