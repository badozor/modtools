### Name: bootvalid
### Title: Validation procedure based on bootstrap for object from 'glm' or
###   'lm'.
### Aliases: bootvalid bootvalid.default summary.bootcorrected


### ** Examples

## glm1

## bootvalid

## histogram of results




