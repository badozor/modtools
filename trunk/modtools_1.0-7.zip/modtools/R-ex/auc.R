### Name: auc
### Title: Area Under Curves
### Aliases: auc


### ** Examples

# y <- rpois(1:10)
# d1 <- density(y)
# auc(d1$x,d1$y)



