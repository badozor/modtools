### Name: scorevalid
### Title: Performance curves
### Aliases: scorevalid scorevalid.default print.scorevalid plot.scorevalid


### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function (y, score, ...) 
{
    UseMethod("scorevalid")
  }



