### Name: pseudoR2
### Title: Pseudo-R2 for object 'glm'
### Aliases: pseudoR2 pseudoR2.glm


### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function (mod0, mod, ...) 
{
    UseMethod("pseudoR2")
  }



