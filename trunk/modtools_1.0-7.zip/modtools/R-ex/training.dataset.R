### Name: training.dataset
### Title: building training and test dataset
### Aliases: training.dataset


### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function (x, cluster = rep(1, length(x)), ratio = 1/4) 
{
    test <- unlist(tapply(x, cluster, function(j) sample(j, round(length(j) * 
        ratio))))
    res <- data.frame(x = x, test = x %in% test, training = !(x %in% 
        test), cluster = cluster)
    attr(res, "ratio") <- ratio
    attr(res, "N") <- length(x)
    attr(res, "Ntest") <- sum(res$test)
    attr(res, "Ntraining") <- sum(res$training)
    return(res)
  }



