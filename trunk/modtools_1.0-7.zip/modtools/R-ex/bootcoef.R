### Name: bootcoef
### Title: ~~function to do ... ~~
### Aliases: bootcoef


### ** Examples


# add an example




