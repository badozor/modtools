### Name: anscresid
### Title: Anscombe's Residuals
### Aliases: anscresid


### ** Examples

## binomial

## poisson

## Gamma




