# include <stdio.h>
# include <stdlib.h>
# include <math.h>
/* new function: 07/25/08 10:33:43 */

void AUC(int* length, double* x, double* y, double* res);


