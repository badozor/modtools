`variogram` <-
		function (object, ...) 
{
	UseMethod("variogram")
}
