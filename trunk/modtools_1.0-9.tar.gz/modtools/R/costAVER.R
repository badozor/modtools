`costAVER` <-
function (y, yhat = 0) 
mean(y - yhat)
