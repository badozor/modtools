`pseudoR2` <-
function (mod0, mod, ...) 
{
    UseMethod("pseudoR2")
}
