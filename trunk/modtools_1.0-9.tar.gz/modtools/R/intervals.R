`intervals` <-
function (object, ...) 
{
    UseMethod("intervals")
}
